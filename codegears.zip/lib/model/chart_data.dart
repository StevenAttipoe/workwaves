

class ChartData {
  ChartData(this.x, this.y);
 
  final String x;
  final double y;
}